%%Please cite if use this code

%Using very basic image processing techniques i have implementd the below code

clc
clear all
close all
%%First of all We will Load Image
img=imread('image005.png');
img = imresize(img,0.5,'bilinear');
oi=img;
%% Remove Vessels
se = strel('disk',10);
if length(size(img)) >= 3
    img(:,:,1) = imclose(img(:,:,1),se);
else
    img = imclose(img,se);
end
figure
subplot(3,3,1)
imshow(img(:,:,1)); % First Channel of Image
title('First Channel')
subplot(3,3,2)
imshow(img(:,:,2));
title('Second Channel')
a = img(:,:,1);
b = img(:,:,2);
b= medfilt2(b);
subplot(3,3,3)
imshow(b);
%%
%%Apply Midiean Filter to Remove Noise and Improve Contrast
title('Miden Filter')
b = imadjust(b);
subplot(3,3,4)
imshow(b);
title('Contrast Enhacement')
b(b<50) = 0;
b3 = b;
[r,c] = size(b3);
%%
%%Create Mask to detect Optic Disc
b3(:,floor(c/2)-150:floor(c/2)+150) = 0;
[i,j] = find(b3 == max(max(b3)));
T = adaptthresh(b, 0.4);
a = imbinarize(a,0.57);
b = imbinarize(b,T);
b2 = imdilate(b,se);
b2(1:5,:) = 1;
b2(end-5:end,:) = 1;
b2 = bwareafilt(b2,1);
b2(1:5,:) = 0;
b2(end-5:end,:) = 0;
b = b .* imcomplement(b2);
b(1:5,:) = 0;
b(end-5:end,:) = 0;
b3 = imbinarize(b3,0.9);
opticDiscPoint = [mean(i), mean(j)];
se2 = strel('disk',5);
c = imdilate(b3,se2);
subplot(3,3,5)
imshow(c);
title('OD Detection')
%% Rest are Exudates
c = imcomplement(c);
d = b .* c;
d = bwareaopen(d,5);
d = imfill(d,'holes');
d = edge(d,'canny');
[i,j] = find(d == 1);
subplot(3,3,6)
imshow(d);
title('OD Remove')
subplot(3,3,7)
imshow(oi);
title('Exudate Boundry')
hold on
plot(j,i,'y.');
plot(opticDiscPoint(2),opticDiscPoint(1),'r+');